package clases;


import java.util.Objects;
public class Pistas {
	private int id;
	private String pista;
	private int longitud;
	private long tiempo;
	private Boolean apertura;
	private int capacidadMax;
	private String dificultad;
	private Double temperatura;
	public Pistas(int id,String pista, int longitud, long tiempo, Boolean apertura, int capacidadMax, String dificultad,
			Double temperatura) {
		super();
		this.id=id;
		this.pista = pista;
		this.longitud = longitud;
		this.tiempo = tiempo;
		this.apertura = apertura;
		this.capacidadMax = capacidadMax;
		this.dificultad = dificultad;
		this.temperatura = temperatura;
		
	}
	public String getPista() {
		return pista;
	}
	public void setPista(String pista) {
		this.pista = pista;
	}
	public int getLongitud() {
		return longitud;
	}
	public void setLongitud(int longitud) {
		this.longitud = longitud;
	}
	public long getTiempo() {
		return tiempo;
	}
	public void setTiempo(long tiempo) {
		this.tiempo = tiempo;
	}
	public Boolean getApertura() {
		return apertura;
	}
	public void setApertura(Boolean apertura) {
		this.apertura = apertura;
	}
	public int getCapacidadMax() {
		return capacidadMax;
	}
	public void setCapacidadMax(int capacidadMax) {
		this.capacidadMax = capacidadMax;
	}
	public String getDificultad() {
		return dificultad;
	}
	public void setDificultad(String dificultad) {
		this.dificultad = dificultad;
	}
	public Double getTemperatura() {
		return temperatura;
	}
	public void setTemperatura(Double temperatura) {
		this.temperatura = temperatura;
	}
	@Override
	public int hashCode() {
		return Objects.hash(apertura, capacidadMax, dificultad,longitud, pista, temperatura, tiempo);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pistas other = (Pistas) obj;
		return Objects.equals(apertura, other.apertura) && capacidadMax == other.capacidadMax
				&& Objects.equals(dificultad, other.dificultad)
				&& longitud == other.longitud && Objects.equals(pista, other.pista)
				&& Objects.equals(temperatura, other.temperatura) && Objects.equals(tiempo, other.tiempo);
	}
	@Override
	public String toString() {
		return "Pistas [pista=" + pista + ", longitud=" + longitud + ", tiempo=" + tiempo + ", apertura=" + apertura
				+ ", capacidadMax=" + capacidadMax + ", dificultad=" + dificultad + ", temperatura=" + temperatura + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
